package com.example.restaurantcapitol.Common;

import com.example.restaurantcapitol.Model.User;

public class Common {

    public static User currentUser;
}
